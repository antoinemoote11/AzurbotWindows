# Azur Bot Windows

Version Windows pour jouer à Azur de Celestia dans Chrome.

## Règles de sécurité

Le bot ne clique que lorsqu'un texte autorisé est reconnu :
- `RENTRER AU VILLAGE` seulement si la barre verte est estimée sous 55 %
- `CONTINUER` seulement si elle est à 55 % ou plus
- `REPARTIR`
- `PARTIR`

Le bouton ARRÊTER stoppe la boucle.

## Construction

Le workflow GitHub Actions fabrique automatiquement un EXE Windows autonome.

Une fois le workflow terminé :
Actions → dernier workflow → Artifacts → `AzurBot-Windows`.

## Utilisation

1. Ouvrir le jeu dans Chrome.
2. Laisser Chrome visible.
3. Lancer `AzurBot.exe`.
4. Cliquer DÉMARRER.
5. Pour arrêter : ARRÊTER.

Note : la première version doit être testée sur le PC réel. La détection de la barre verte est basée sur la disposition fournie et peut nécessiter un ajustement selon la résolution et le zoom de Chrome.
