# Azur Bot Windows

- Interface DÉMARRER / ARRÊTER
- Curseur du seuil de PV : 25 %, 50 % ou 75 %
- Affichage du HP estimé
- Fenêtres reconnues : SUPER, COMPRIS, CONFIRMER, REPARTIR, PARTIR, RENTrER AU VILLAGE et CONTINUER.
- Sur un niveau du héros, attend 2 secondes avant le clic sur le + de Force, puis confirme si le bouton est encore détecté.

La reconnaissance doit être testée sur le PC réel et peut demander un réglage selon la résolution et le zoom de Chrome.
