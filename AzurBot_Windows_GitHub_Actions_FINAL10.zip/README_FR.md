# Azur Bot Windows FINAL9

Améliorations :
- Curseur de seuil PV fluide de 25 à 100 %, réglable par pas de 1 %. Repères visuels tous les 25 %.
- Le bot privilégie la lecture OCR des PV actuels / PV maximum affichés à droite de la barre.
- Si les chiffres ne sont pas lisibles, il mesure la barre verte dans la zone proche du libellé PV. Si la lecture est incertaine, il ne clique pas sur « Rentrer au village ».
- Conservation des actions existantes : niveau du héros (Force puis Confirmer), météo, niveau du compagnon, continuer, repartir et partir.

Le projet est destiné à être placé dans le dépôt GitHub utilisé par le workflow de compilation Windows.
