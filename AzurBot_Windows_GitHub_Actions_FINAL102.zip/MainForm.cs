using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Windows.Forms;
using Windows.Globalization;
using Windows.Media.Ocr;
using Windows.Graphics.Imaging;
using Windows.Storage.Streams;

namespace AzurBot;

public sealed class MainForm : Form
{
    private readonly Button startButton = new() { Text = "DÉMARRER", Width = 150, Height = 50 };
    private readonly Button stopButton = new() { Text = "ARRÊTER", Width = 150, Height = 50, Enabled = false };
    private readonly Label status = new() { Text = "En attente", AutoSize = true };
    private readonly Label hpLabel = new() { Text = "HP : --", AutoSize = true };
    private readonly Label thresholdLabel = new() { Text = "Retour au village sous : 50 %", AutoSize = true };
    private readonly TrackBar thresholdTrackBar = new() { Minimum = 25, Maximum = 100, Value = 50, TickFrequency = 25, SmallChange = 1, LargeChange = 5, Width = 320, Height = 48 };
    private volatile int returnThreshold = 50;
    private CancellationTokenSource? cts;
    private bool busy;
    private double? lastHp;
    private DateTime lastHpAt = DateTime.MinValue;
    private int lowCount;

    public MainForm()
    {
        Text = "Azur Bot";
        Width = 390;
        Height = 220;
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;

        var title = new Label
        {
            Text = "AZUR BOT",
            Font = new Font("Segoe UI", 18, FontStyle.Bold),
            AutoSize = true,
            Left = 25, Top = 18
        };

        startButton.Left = 25; startButton.Top = 65;
        stopButton.Left = 190; stopButton.Top = 65;
        status.Left = 25; status.Top = 120;
        thresholdLabel.Left = 25; thresholdLabel.Top = 150;
        thresholdTrackBar.Left = 25; thresholdTrackBar.Top = 172;
        hpLabel.Left = 25; hpLabel.Top = 220;
        thresholdTrackBar.Scroll += (_, _) =>
        {
            int v = thresholdTrackBar.Value;
            returnThreshold = v;
            thresholdLabel.Text = $"Retour au village sous : {v} %";
        };

        startButton.Click += (_, _) => StartBot();
        stopButton.Click += (_, _) => StopBot();
        Height = 305;
        Controls.AddRange([title, startButton, stopButton, status, thresholdLabel, thresholdTrackBar, hpLabel]);

        FormClosing += (_, _) => StopBot();
    }

    private void StartBot()
    {
        if (busy) return;
        busy = true;
        cts = new CancellationTokenSource();
        startButton.Enabled = false;
        stopButton.Enabled = true;
        SetStatus("Démarré. Place le jeu sur Chrome.");
        _ = Task.Run(() => LoopAsync(cts.Token));
    }

    private void StopBot()
    {
        cts?.Cancel();
        busy = false;
        startButton.Enabled = true;
        stopButton.Enabled = false;
        SetStatus("Arrêté");
    }

    private void SetStatus(string text)
    {
        if (IsDisposed) return;
        BeginInvoke(() => status.Text = text);
    }

    private void SetHp(double? hp, string source = "")
    {
        if (IsDisposed) return;
        BeginInvoke(() => hpLabel.Text = hp.HasValue
            ? $"HP : {hp.Value:0} %" + (source.Length > 0 ? $" ({source})" : "")
            : "HP : --");
    }

    private async Task LoopAsync(CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            try
            {
                using var bmp = CaptureVirtualScreen();
                // One OCR pass per frame, shared by the text detection and the HP reading.
                var ocr = await OcrAsync(bmp);
                var text = ocr.Text ?? "";

                var reading = await DetectHpAsync(bmp, ocr);
                if (reading.Hp.HasValue)
                {
                    lastHp = reading.Hp;
                    lastHpAt = DateTime.UtcNow;
                }
                else if (lastHp.HasValue && (DateTime.UtcNow - lastHpAt).TotalSeconds < 12)
                {
                    // The HP bar is often hidden by the victory popup: reuse the last reading from the fight.
                    reading = (lastHp, "mémorisé");
                }
                double? hp = reading.Hp;
                SetHp(hp, reading.Source);

                bool wantReturn = Contains(text, "RENTRER AU VILLAGE") && hp.HasValue && hp.Value < returnThreshold;
                if (!wantReturn) lowCount = 0;

                // Safety rule: only click a known target when its text is actually recognized.
                // Hero level-up popup: put exactly one point into Force, then confirm.
                if (Contains(text, "CONFIRMER") && Contains(text, "Force"))
                {
                    SetStatus("Niveau du héros : attente avant + Force");
                    await Task.Delay(2000, token);

                    // Capture a fresh screen after the wait, then click the green + on the Force row.
                    using var levelScreen = CaptureVirtualScreen();
                    bool forceClicked = await ClickForcePlusAsync(levelScreen, token);
                    if (forceClicked)
                    {
                        await Task.Delay(1200, token);
                        using var bmp2 = CaptureVirtualScreen();
                        var text2 = await ReadFrenchTextAsync(bmp2);
                        if (Contains(text2, "CONFIRMER"))
                        {
                            SetStatus("Force ajoutée : clic sur CONFIRMER");
                            await ClickConfirmAsync(bmp2, token);
                        }
                        else
                        {
                            SetStatus("Point Force cliqué, confirmation non détectée");
                        }
                    }
                    else
                    {
                        SetStatus("Niveau détecté, ligne Force introuvable : je n'ai pas confirmé");
                    }
                }
                // Event popups have priority over all gameplay buttons.
                else if (Contains(text, "COMPRIS"))
                {
                    SetStatus("Météo : compris !");
                    await ClickTextAsync(bmp, text, "COMPRIS", token);
                }
                // Companion level-up popup: close it first with "SUPER !".
                else if (Contains(text, "SUPER"))
                {
                    SetStatus("Niveau du compagnon : Super !");
                    await ClickTextAsync(bmp, text, "SUPER", token);
                }
                else if (wantReturn)
                {
                    // Require two consecutive low readings so one misread digit cannot send us home.
                    if (++lowCount >= 2)
                    {
                        lowCount = 0;
                        SetStatus($"PV sous {returnThreshold} % : retour au village");
                        await ClickTextAsync(bmp, text, "RENTRER AU VILLAGE", token);
                    }
                    else
                    {
                        SetStatus("PV bas détectés : vérification...");
                    }
                }
                else if (Contains(text, "CONTINUER") && hp.HasValue && hp.Value >= returnThreshold)
                {
                    SetStatus("Victoire : continuer");
                    await ClickTextAsync(bmp, text, "CONTINUER", token);
                }
                else if (Contains(text, "REPARTIR"))
                {
                    SetStatus("Rapport : repartir");
                    await ClickTextAsync(bmp, text, "REPARTIR", token);
                }
                else if (Contains(text, "PARTIR"))
                {
                    SetStatus("Préparation : partir");
                    await ClickTextAsync(bmp, text, "PARTIR", token);
                }
                else if (!hp.HasValue && (Contains(text, "RENTRER AU VILLAGE") || Contains(text, "CONTINUER")))
                {
                    SetStatus("PV illisibles : aucune action (capture sur le Bureau)");
                    DumpDebug(bmp, ocr);
                }
                else
                {
                    SetStatus("Analyse...");
                }

                await Task.Delay(900, token);
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex)
            {
                SetStatus("Erreur : " + ex.Message);
                await Task.Delay(1500, token);
            }
        }
    }

    private static bool Contains(string text, string wanted)
        => text.Replace("’", "'").IndexOf(wanted, StringComparison.OrdinalIgnoreCase) >= 0;

    private static Bitmap CaptureVirtualScreen()
    {
        var bounds = SystemInformation.VirtualScreen;
        var bmp = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format32bppArgb);
        using var g = Graphics.FromImage(bmp);
        g.CopyFromScreen(bounds.Left, bounds.Top, 0, 0, bounds.Size);
        return bmp;
    }

    private static async Task<OcrResult> OcrAsync(Bitmap bmp)
    {
        using var ms = new MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;
        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);
        var decoder = await BitmapDecoder.CreateAsync(ras);
        var softwareBitmap = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();
        if (engine is null) throw new InvalidOperationException("OCR Windows indisponible (installer la langue française)");
        return await engine.RecognizeAsync(softwareBitmap);
    }

    // HP reading, three strategies from most to least reliable:
    //  1. "current / max" numbers in the full-screen OCR, next to the PV label
    //  2. same numbers read again on a 3x enlarged crop around the label (small text is the usual failure)
    //  3. fill ratio of the green bar, only if both ends of the bar are clearly delimited
    private static async Task<(double? Hp, string Source)> DetectHpAsync(Bitmap bmp, OcrResult full)
    {
        var labels = new List<Windows.Foundation.Rect>();
        foreach (var line in full.Lines)
            foreach (var w in line.Words)
                if (Regex.IsMatch(w.Text.Trim(), @"^P\s?[VUY][:.]?$|^PV(?=\d)", RegexOptions.IgnoreCase))
                    labels.Add(w.BoundingRect);
        labels = labels.OrderBy(r => r.Y).ToList();
        if (labels.Count == 0) return (null, "");

        foreach (var label in labels)
        {
            double cy = label.Y + label.Height / 2;
            double tolerance = Math.Max(60, label.Height * 3);
            var near = full.Lines
                .Select(l => new { l.Text, Rect = GetLineRect(l) })
                .Where(x => x.Rect.Width > 0
                            && x.Rect.X + x.Rect.Width > label.X
                            && Math.Abs(x.Rect.Y + x.Rect.Height / 2 - cy) < tolerance)
                .OrderBy(x => Math.Abs(x.Rect.Y + x.Rect.Height / 2 - cy));
            foreach (var x in near)
            {
                var pair = ParseHpPair(x.Text);
                if (pair.HasValue) return (Percent(pair.Value), "OCR");
            }
        }

        foreach (var label in labels)
        {
            var pair = await ZoomReadPairAsync(bmp, label);
            if (pair.HasValue) return (Percent(pair.Value), "OCR zoom");
        }

        foreach (var label in labels)
        {
            var bar = MeasureBar(bmp, label);
            if (bar.HasValue) return (bar.Value, "barre");
        }
        return (null, "");
    }

    private static double Percent((int Current, int Maximum) p)
        => Math.Clamp(100.0 * p.Current / p.Maximum, 0, 100);

    private static async Task<(int Current, int Maximum)?> ZoomReadPairAsync(Bitmap bmp, Windows.Foundation.Rect label)
    {
        int x0 = Math.Max(0, (int)label.X - 10);
        int y0 = Math.Max(0, (int)(label.Y - label.Height));
        int w = Math.Min(bmp.Width - x0, Math.Max(400, (int)(bmp.Width * 0.5)));
        int h = Math.Min(bmp.Height - y0, Math.Max(24, (int)(label.Height * 4)));
        if (w < 20 || h < 10) return null;
        const int scale = 3;

        foreach (bool invert in new[] { false, true })
        {
            using var zoom = new Bitmap(w * scale, h * scale, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(zoom))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.DrawImage(bmp, new Rectangle(0, 0, zoom.Width, zoom.Height),
                            new Rectangle(x0, y0, w, h), GraphicsUnit.Pixel);
            }
            if (invert) GrayInvert(zoom);
            var res = await OcrAsync(zoom);
            foreach (var line in res.Lines)
            {
                var pair = ParseHpPair(line.Text);
                if (pair.HasValue) return pair;
            }
        }
        return null;
    }

    // Light text on a dark/coloured background is hard for the Windows OCR: give it dark text on light.
    private static void GrayInvert(Bitmap bmp)
    {
        var rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        var data = bmp.LockBits(rect, ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
        try
        {
            var buf = new byte[Math.Abs(data.Stride) * bmp.Height];
            Marshal.Copy(data.Scan0, buf, 0, buf.Length);
            for (int y = 0; y < bmp.Height; y++)
            {
                int row = y * data.Stride;
                for (int x = 0; x < bmp.Width; x++)
                {
                    int i = row + x * 4;
                    int gray = (buf[i + 2] * 30 + buf[i + 1] * 59 + buf[i] * 11) / 100;
                    byte v = (byte)(255 - gray);
                    buf[i] = buf[i + 1] = buf[i + 2] = v;
                    buf[i + 3] = 255;
                }
            }
            Marshal.Copy(buf, 0, data.Scan0, buf.Length);
        }
        finally { bmp.UnlockBits(data); }
    }

    // Measures green / (green + empty part) on the row where the green run is longest.
    // Returns null unless the right end of the bar is delimited by a bright frame, so a dark
    // background can never be mistaken for an empty bar.
    private static double? MeasureBar(Bitmap bmp, Windows.Foundation.Rect label)
    {
        int x0 = Math.Max(0, (int)label.X - 20);
        int y0 = Math.Max(0, (int)(label.Y - label.Height * 0.5));
        int x1 = Math.Min(bmp.Width, (int)(label.X + bmp.Width * 0.45));
        int y1 = Math.Min(bmp.Height, (int)(label.Y + label.Height * 3.5));
        int w = x1 - x0, h = y1 - y0;
        if (w < 80 || h < 4) return null;

        var data = bmp.LockBits(new Rectangle(x0, y0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        int stride = data.Stride;
        var buf = new byte[Math.Abs(stride) * h];
        try { Marshal.Copy(data.Scan0, buf, 0, buf.Length); }
        finally { bmp.UnlockBits(data); }

        bool IsGreen(int x, int y)
        {
            int i = y * stride + x * 4;
            int b = buf[i], g = buf[i + 1], r = buf[i + 2];
            return g > 65 && g > r * 1.25 && g > b * 1.08;
        }
        int Max(int x, int y)
        {
            int i = y * stride + x * 4;
            return Math.Max(buf[i], Math.Max(buf[i + 1], buf[i + 2]));
        }

        double? best = null;
        int bestGreen = 0;
        for (int y = 0; y < h; y++)
        {
            int run = 0, runStart = 0, gap = 0, bestRun = 0, bs = 0, be = 0;
            for (int x = 0; x < w; x++)
            {
                if (IsGreen(x, y))
                {
                    if (run == 0) runStart = x;
                    run++; gap = 0;
                    if (run > bestRun) { bestRun = run; bs = runStart; be = x; }
                }
                else if (run > 0 && ++gap > 2) { run = 0; gap = 0; }
            }
            if (bestRun < 4 || bestRun <= bestGreen) continue;

            int e = be + 1, bright = 0;
            bool bounded = false;
            while (e < w)
            {
                if (IsGreen(e, y)) { be = e; bright = 0; }
                else if (Max(e, y) >= 140)
                {
                    if (++bright >= 2) { bounded = true; break; }
                }
                else bright = 0;
                e++;
            }
            if (!bounded) continue;
            int trackEnd = Math.Max(be + 1, e - 1);
            int track = trackEnd - bs;
            if (track < 80) continue;

            bestGreen = bestRun;
            best = Math.Clamp(100.0 * (be - bs + 1) / track, 0, 100);
        }
        return best;
    }

    private static void DumpDebug(Bitmap bmp, OcrResult ocr)
    {
        try
        {
            if (dumpCount >= 12 || (DateTime.Now - lastDump).TotalSeconds < 5) return;
            lastDump = DateTime.Now;
            dumpCount++;
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "AzurBot_debug");
            Directory.CreateDirectory(dir);
            var stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            bmp.Save(Path.Combine(dir, stamp + ".png"), ImageFormat.Png);
            var sb = new StringBuilder();
            foreach (var line in ocr.Lines)
            {
                var r = GetLineRect(line);
                sb.AppendLine($"{r.X:0},{r.Y:0},{r.Width:0},{r.Height:0} | {line.Text}");
            }
            File.WriteAllText(Path.Combine(dir, stamp + ".txt"), sb.ToString());
        }
        catch { /* debug only */ }
    }

    private static DateTime lastDump = DateTime.MinValue;
    private static int dumpCount;

    // WinRT OcrLine does not expose BoundingRect directly. Build it from the
    // bounding rectangles of its recognized words.
    private static Windows.Foundation.Rect GetLineRect(OcrLine line)
    {
        var words = line.Words;
        if (words.Count == 0)
            return new Windows.Foundation.Rect(0, 0, 0, 0);

        double left = words.Min(w => w.BoundingRect.X);
        double top = words.Min(w => w.BoundingRect.Y);
        double right = words.Max(w => w.BoundingRect.X + w.BoundingRect.Width);
        double bottom = words.Max(w => w.BoundingRect.Y + w.BoundingRect.Height);
        return new Windows.Foundation.Rect(left, top, right - left, bottom - top);
    }

    private static (int Current, int Maximum)? ParseHpPair(string text)
    {
        // OCR often turns 0 into O and 1 into I / l / | in small game fonts.
        var t = text.Replace('O', '0').Replace('o', '0').Replace('I', '1').Replace('l', '1').Replace('|', '1')
                    .Replace(' ', ' ');
        const string num = @"(?:\d{1,3}(?:[ .,]\d{3})+|\d+)";
        var match = Regex.Match(t, $@"(?<cur>{num})\s*[/\\]\s*(?<max>{num})");
        if (!match.Success) return null;
        static bool TryDigits(string value, out int number)
            => int.TryParse(Regex.Replace(value, @"[^0-9]", ""), out number);
        if (!TryDigits(match.Groups["cur"].Value, out int current) ||
            !TryDigits(match.Groups["max"].Value, out int maximum) || maximum <= 0 || current > maximum)
            return null;
        return (current, maximum);
    }

    private static async Task<string> ReadFrenchTextAsync(Bitmap bmp)
    {
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;

        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);

        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();

        var result = await engine.RecognizeAsync(sb);
        return result.Text ?? "";
    }

    private static async Task<bool> ClickForcePlusAsync(Bitmap bmp, CancellationToken token)
    {
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;

        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);

        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();
        var result = await engine.RecognizeAsync(sb);

        foreach (var line in result.Lines)
        {
            if (line.Text.IndexOf("Force", StringComparison.OrdinalIgnoreCase) < 0)
                continue;

            var rects = line.Words.Select(w => w.BoundingRect).ToArray();
            if (rects.Length == 0) continue;

            double top = rects.Min(r => r.Y);
            double bottom = rects.Max(r => r.Y + r.Height);
            int y = (int)((top + bottom) / 2);

            // The green + is to the right of the grey minus. Use the right-hand button,
            // not the previous coordinate which landed too far left.
            int x = (int)(bmp.Width * 0.68);

            NativeClick.Click(x + SystemInformation.VirtualScreen.Left,
                              y + SystemInformation.VirtualScreen.Top);
            await Task.Delay(300, token);
            return true;
        }
        return false;
    }

    private static async Task ClickConfirmAsync(Bitmap bmp, CancellationToken token)
    {
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;
        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);
        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();
        var result = await engine.RecognizeAsync(sb);
        foreach (var line in result.Lines)
        {
            if (line.Text.IndexOf("CONFIRMER", StringComparison.OrdinalIgnoreCase) < 0)
                continue;
            var rects = line.Words.Select(w => w.BoundingRect).ToArray();
            if (rects.Length == 0) continue;
            int x = (int)((rects.Min(r => r.X) + rects.Max(r => r.X + r.Width)) / 2);
            int y = (int)((rects.Min(r => r.Y) + rects.Max(r => r.Y + r.Height)) / 2);
            NativeClick.Click(x + SystemInformation.VirtualScreen.Left,
                              y + SystemInformation.VirtualScreen.Top);
            await Task.Delay(1400, token);
            return;
        }
        // Fallback for the supplied portrait layout when OCR misses the button label.
        int fallbackX = (int)(bmp.Width * 0.50);
        int fallbackY = (int)(bmp.Height * 0.91);
        NativeClick.Click(fallbackX + SystemInformation.VirtualScreen.Left,
                          fallbackY + SystemInformation.VirtualScreen.Top);
        await Task.Delay(1400, token);
    }

    private static async Task ClickTextAsync(Bitmap bmp, string fullText, string wanted, CancellationToken token)
    {
        // Re-run OCR with word boxes so we can click the recognized button itself.
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;

        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);

        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();
        var result = await engine.RecognizeAsync(sb);

        var normalizedWanted = wanted.Replace("!", "").Trim();
        foreach (var line in result.Lines)
        {
            var lineText = line.Text.Replace("!", "").Trim();
            if (lineText.IndexOf(normalizedWanted, StringComparison.OrdinalIgnoreCase) < 0)
                continue;

            var rect = line.Words.Select(w => w.BoundingRect).ToArray();
            if (rect.Length == 0) continue;

            double left = rect.Min(r => r.X);
            double top = rect.Min(r => r.Y);
            double right = rect.Max(r => r.X + r.Width);
            double bottom = rect.Max(r => r.Y + r.Height);

            int x = (int)((left + right) / 2);
            int y = (int)((top + bottom) / 2);

            // Avoid accidental clicks near screen edges.
            if (x < 5 || y < 5 || x >= bmp.Width - 5 || y >= bmp.Height - 5) return;

            NativeClick.Click(x + SystemInformation.VirtualScreen.Left,
                              y + SystemInformation.VirtualScreen.Top);
            await Task.Delay(1400, token);
            return;
        }
    }
}
