# Azur Bot Windows FINAL8

Corrections ciblées pour l'écran portrait montré :
- Le clic sur le + vert de Force est placé à 68 % de la largeur, et non 78,5 %.
- Le bot attend 2 secondes puis refait une capture avant de cliquer.
- Après le +, il attend puis clique sur CONFIRMER via OCR; si le texte n'est pas lu, il utilise le point de confirmation en bas au centre pour cette disposition d'écran.
- Le bot ne confirme pas si le clic Force n'a pas été envoyé.
- Interface : DÉMARRER / ARRÊTER et seuil PV 25/50/75 %.
