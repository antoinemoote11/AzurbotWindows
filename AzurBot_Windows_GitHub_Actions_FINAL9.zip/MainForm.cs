using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Windows.Forms;
using Windows.Globalization;
using Windows.Media.Ocr;
using Windows.Graphics.Imaging;
using Windows.Storage.Streams;

namespace AzurBot;

public sealed class MainForm : Form
{
    private readonly Button startButton = new() { Text = "DÉMARRER", Width = 150, Height = 50 };
    private readonly Button stopButton = new() { Text = "ARRÊTER", Width = 150, Height = 50, Enabled = false };
    private readonly Label status = new() { Text = "En attente", AutoSize = true };
    private readonly Label hpLabel = new() { Text = "HP : --", AutoSize = true };
    private readonly Label thresholdLabel = new() { Text = "Retour au village sous : 50 %", AutoSize = true };
    private readonly TrackBar thresholdTrackBar = new() { Minimum = 25, Maximum = 100, Value = 50, TickFrequency = 25, SmallChange = 1, LargeChange = 5, Width = 320, Height = 48 };
    private volatile int returnThreshold = 50;
    private CancellationTokenSource? cts;
    private bool busy;

    public MainForm()
    {
        Text = "Azur Bot";
        Width = 390;
        Height = 220;
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;

        var title = new Label
        {
            Text = "AZUR BOT",
            Font = new Font("Segoe UI", 18, FontStyle.Bold),
            AutoSize = true,
            Left = 25, Top = 18
        };

        startButton.Left = 25; startButton.Top = 65;
        stopButton.Left = 190; stopButton.Top = 65;
        status.Left = 25; status.Top = 120;
        thresholdLabel.Left = 25; thresholdLabel.Top = 150;
        thresholdTrackBar.Left = 25; thresholdTrackBar.Top = 172;
        hpLabel.Left = 25; hpLabel.Top = 220;
        thresholdTrackBar.Scroll += (_, _) =>
        {
            int v = thresholdTrackBar.Value;
            returnThreshold = v;
            thresholdLabel.Text = $"Retour au village sous : {v} %";
        };

        startButton.Click += (_, _) => StartBot();
        stopButton.Click += (_, _) => StopBot();
        Height = 305;
        Controls.AddRange([title, startButton, stopButton, status, thresholdLabel, thresholdTrackBar, hpLabel]);

        FormClosing += (_, _) => StopBot();
    }

    private void StartBot()
    {
        if (busy) return;
        busy = true;
        cts = new CancellationTokenSource();
        startButton.Enabled = false;
        stopButton.Enabled = true;
        SetStatus("Démarré. Place le jeu sur Chrome.");
        _ = Task.Run(() => LoopAsync(cts.Token));
    }

    private void StopBot()
    {
        cts?.Cancel();
        busy = false;
        startButton.Enabled = true;
        stopButton.Enabled = false;
        SetStatus("Arrêté");
    }

    private void SetStatus(string text)
    {
        if (IsDisposed) return;
        BeginInvoke(() => status.Text = text);
    }

    private void SetHp(double? hp)
    {
        if (IsDisposed) return;
        BeginInvoke(() => hpLabel.Text = hp.HasValue ? $"HP : {hp.Value:0} %" : "HP : --");
    }

    private async Task LoopAsync(CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            try
            {
                using var bmp = CaptureVirtualScreen();
                // Prefer the displayed current/max HP numbers; use the green bar only as fallback.
                var hp = await DetectHpPercentAsync(bmp);
                SetHp(hp);

                var text = await ReadFrenchTextAsync(bmp);

                // Safety rule: only click a known target when its text is actually recognized.
                // Hero level-up popup: put exactly one point into Force, then confirm.
                if (Contains(text, "CONFIRMER") && Contains(text, "Force"))
                {
                    SetStatus("Niveau du héros : attente avant + Force");
                    await Task.Delay(2000, token);

                    // Capture a fresh screen after the wait, then click the green + on the Force row.
                    using var levelScreen = CaptureVirtualScreen();
                    bool forceClicked = await ClickForcePlusAsync(levelScreen, token);
                    if (forceClicked)
                    {
                        await Task.Delay(1200, token);
                        using var bmp2 = CaptureVirtualScreen();
                        var text2 = await ReadFrenchTextAsync(bmp2);
                        if (Contains(text2, "CONFIRMER"))
                        {
                            SetStatus("Force ajoutée : clic sur CONFIRMER");
                            await ClickConfirmAsync(bmp2, token);
                        }
                        else
                        {
                            SetStatus("Point Force cliqué, confirmation non détectée");
                        }
                    }
                    else
                    {
                        SetStatus("Niveau détecté, ligne Force introuvable : je n'ai pas confirmé");
                    }
                }
                // Event popups have priority over all gameplay buttons.
                else if (Contains(text, "COMPRIS"))
                {
                    SetStatus("Météo : compris !");
                    await ClickTextAsync(bmp, text, "COMPRIS", token);
                }
                // Companion level-up popup: close it first with "SUPER !".
                else if (Contains(text, "SUPER"))
                {
                    SetStatus("Niveau du compagnon : Super !");
                    await ClickTextAsync(bmp, text, "SUPER", token);
                }
                else if (Contains(text, "RENTRER AU VILLAGE") && hp.HasValue && hp.Value < returnThreshold)
                {
                    SetStatus($"PV sous {returnThreshold} % : retour au village");
                    await ClickTextAsync(bmp, text, "RENTRER AU VILLAGE", token);
                }
                else if (Contains(text, "CONTINUER") && hp.HasValue && hp.Value >= returnThreshold)
                {
                    SetStatus("Victoire : continuer");
                    await ClickTextAsync(bmp, text, "CONTINUER", token);
                }
                else if (Contains(text, "REPARTIR"))
                {
                    SetStatus("Rapport : repartir");
                    await ClickTextAsync(bmp, text, "REPARTIR", token);
                }
                else if (Contains(text, "PARTIR"))
                {
                    SetStatus("Préparation : partir");
                    await ClickTextAsync(bmp, text, "PARTIR", token);
                }
                else
                {
                    SetStatus("Analyse...");
                }

                await Task.Delay(900, token);
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex)
            {
                SetStatus("Erreur : " + ex.Message);
                await Task.Delay(1500, token);
            }
        }
    }

    private static bool Contains(string text, string wanted)
        => text.Replace("’", "'").IndexOf(wanted, StringComparison.OrdinalIgnoreCase) >= 0;

    private static Bitmap CaptureVirtualScreen()
    {
        var bounds = SystemInformation.VirtualScreen;
        var bmp = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format32bppArgb);
        using var g = Graphics.FromImage(bmp);
        g.CopyFromScreen(bounds.Left, bounds.Top, 0, 0, bounds.Size);
        return bmp;
    }

    private static async Task<double?> DetectHpPercentAsync(Bitmap bmp)
    {
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;
        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);
        var decoder = await BitmapDecoder.CreateAsync(ras);
        var softwareBitmap = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();
        if (engine is null) return null;
        var result = await engine.RecognizeAsync(softwareBitmap);

        // Find the player's PV label so that enemy HP fractions elsewhere on screen are ignored.
        var pvLine = result.Lines
            .Where(l => Regex.IsMatch(l.Text, @"\bP\s*V\b", RegexOptions.IgnoreCase))
            .OrderBy(l => l.BoundingRect.Y)
            .FirstOrDefault();
        if (pvLine is null) return null;

        // The current/max numbers are normally printed on the same row as "PV".
        // If OCR splits them into a separate line, choose the closest fraction near that label.
        var fractions = result.Lines
            .Select(l => new { Line = l, Pair = ParseHpPair(l.Text) })
            .Where(x => x.Pair.HasValue)
            .Select(x => new { x.Line, Pair = x.Pair!.Value,
                Distance = Math.Abs((x.Line.BoundingRect.Y + x.Line.BoundingRect.Height / 2) -
                                    (pvLine.BoundingRect.Y + pvLine.BoundingRect.Height / 2)) })
            .Where(x => x.Distance < 95)
            .OrderBy(x => x.Distance)
            .ToList();

        if (fractions.Count > 0)
        {
            var pair = fractions[0].Pair;
            if (pair.Maximum > 0 && pair.Current >= 0 && pair.Current <= pair.Maximum)
                return Math.Clamp(100.0 * pair.Current / pair.Maximum, 0, 100);
        }

        // Fallback: measure green pixels only in the narrow strip just below the player's PV label.
        int x0 = Math.Max(0, (int)pvLine.BoundingRect.X - 2);
        int x1 = Math.Min(bmp.Width, x0 + (int)(bmp.Width * 0.48));
        int y0 = Math.Max(0, (int)(pvLine.BoundingRect.Y + pvLine.BoundingRect.Height));
        int y1 = Math.Min(bmp.Height, y0 + 48);
        int bestRun = 0;
        int bestTotal = 0;
        for (int y = y0; y < y1; y += 2)
        {
            int run = 0, localBest = 0;
            for (int x = x0; x < x1; x += 2)
            {
                var c = bmp.GetPixel(x, y);
                bool green = c.G > 65 && c.G > c.R * 1.25 && c.G > c.B * 1.08;
                if (green) { run++; localBest = Math.Max(localBest, run); }
                else run = 0;
            }
            if (localBest > bestRun) { bestRun = localBest; bestTotal = Math.Max(1, (x1 - x0) / 2); }
        }
        if (bestRun < 8 || bestTotal == 0) return null;
        return Math.Clamp(100.0 * bestRun / bestTotal, 0, 100);
    }

    private static (int Current, int Maximum)? ParseHpPair(string text)
    {
        var match = Regex.Match(text, @"(?<cur>\d[\d\s.,]{0,12})\s*/\s*(?<max>\d[\d\s.,]{0,12})");
        if (!match.Success) return null;
        static bool TryDigits(string value, out int number)
        {
            var digits = Regex.Replace(value, @"[^0-9]", "");
            return int.TryParse(digits, out number);
        }
        if (!TryDigits(match.Groups["cur"].Value, out int current) ||
            !TryDigits(match.Groups["max"].Value, out int maximum) || maximum <= 0 || current > maximum)
            return null;
        return (current, maximum);
    }

    private static async Task<string> ReadFrenchTextAsync(Bitmap bmp)
    {
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;

        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);

        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();

        var result = await engine.RecognizeAsync(sb);
        return result.Text ?? "";
    }

    private static async Task<bool> ClickForcePlusAsync(Bitmap bmp, CancellationToken token)
    {
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;

        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);

        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();
        var result = await engine.RecognizeAsync(sb);

        foreach (var line in result.Lines)
        {
            if (line.Text.IndexOf("Force", StringComparison.OrdinalIgnoreCase) < 0)
                continue;

            var rects = line.Words.Select(w => w.BoundingRect).ToArray();
            if (rects.Length == 0) continue;

            double top = rects.Min(r => r.Y);
            double bottom = rects.Max(r => r.Y + r.Height);
            int y = (int)((top + bottom) / 2);

            // The green + is to the right of the grey minus. Use the right-hand button,
            // not the previous coordinate which landed too far left.
            int x = (int)(bmp.Width * 0.68);

            NativeClick.Click(x + SystemInformation.VirtualScreen.Left,
                              y + SystemInformation.VirtualScreen.Top);
            await Task.Delay(300, token);
            return true;
        }
        return false;
    }

    private static async Task ClickConfirmAsync(Bitmap bmp, CancellationToken token)
    {
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;
        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);
        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();
        var result = await engine.RecognizeAsync(sb);
        foreach (var line in result.Lines)
        {
            if (line.Text.IndexOf("CONFIRMER", StringComparison.OrdinalIgnoreCase) < 0)
                continue;
            var rects = line.Words.Select(w => w.BoundingRect).ToArray();
            if (rects.Length == 0) continue;
            int x = (int)((rects.Min(r => r.X) + rects.Max(r => r.X + r.Width)) / 2);
            int y = (int)((rects.Min(r => r.Y) + rects.Max(r => r.Y + r.Height)) / 2);
            NativeClick.Click(x + SystemInformation.VirtualScreen.Left,
                              y + SystemInformation.VirtualScreen.Top);
            await Task.Delay(1400, token);
            return;
        }
        // Fallback for the supplied portrait layout when OCR misses the button label.
        int fallbackX = (int)(bmp.Width * 0.50);
        int fallbackY = (int)(bmp.Height * 0.91);
        NativeClick.Click(fallbackX + SystemInformation.VirtualScreen.Left,
                          fallbackY + SystemInformation.VirtualScreen.Top);
        await Task.Delay(1400, token);
    }

    private static async Task ClickTextAsync(Bitmap bmp, string fullText, string wanted, CancellationToken token)
    {
        // Re-run OCR with word boxes so we can click the recognized button itself.
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;

        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);

        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();
        var result = await engine.RecognizeAsync(sb);

        var normalizedWanted = wanted.Replace("!", "").Trim();
        foreach (var line in result.Lines)
        {
            var lineText = line.Text.Replace("!", "").Trim();
            if (lineText.IndexOf(normalizedWanted, StringComparison.OrdinalIgnoreCase) < 0)
                continue;

            var rect = line.Words.Select(w => w.BoundingRect).ToArray();
            if (rect.Length == 0) continue;

            double left = rect.Min(r => r.X);
            double top = rect.Min(r => r.Y);
            double right = rect.Max(r => r.X + r.Width);
            double bottom = rect.Max(r => r.Y + r.Height);

            int x = (int)((left + right) / 2);
            int y = (int)((top + bottom) / 2);

            // Avoid accidental clicks near screen edges.
            if (x < 5 || y < 5 || x >= bmp.Width - 5 || y >= bmp.Height - 5) return;

            NativeClick.Click(x + SystemInformation.VirtualScreen.Left,
                              y + SystemInformation.VirtualScreen.Top);
            await Task.Delay(1400, token);
            return;
        }
    }
}
