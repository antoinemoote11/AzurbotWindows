# Azur Bot Windows FINAL7

Corrections :
- Attend 2 secondes avant de traiter la fenêtre de niveau du héros.
- Reprend une capture d'écran fraîche après l'attente.
- Clique plus à droite, sur le bouton vert + de la ligne Force (au lieu de la zone du bouton moins).
- Attend 1,2 seconde après le clic.
- Ne clique sur CONFIRMER que si le clic Force a été envoyé et que CONFIRMER est toujours détecté.
- Si la ligne Force n'est pas reconnue, ne confirme pas et affiche un statut.

Interface : DÉMARRER / ARRÊTER et seuil de PV réglable par paliers 25/50/75 %.
