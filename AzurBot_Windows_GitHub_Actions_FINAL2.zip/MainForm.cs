using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Windows.Forms;
using Windows.Globalization;
using Windows.Media.Ocr;
using Windows.Graphics.Imaging;
using Windows.Storage.Streams;

namespace AzurBot;

public sealed class MainForm : Form
{
    private readonly Button startButton = new() { Text = "DÉMARRER", Width = 150, Height = 50 };
    private readonly Button stopButton = new() { Text = "ARRÊTER", Width = 150, Height = 50, Enabled = false };
    private readonly Label status = new() { Text = "En attente", AutoSize = true };
    private readonly Label hpLabel = new() { Text = "HP : --", AutoSize = true };
    private CancellationTokenSource? cts;
    private bool busy;

    public MainForm()
    {
        Text = "Azur Bot";
        Width = 390;
        Height = 220;
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;

        var title = new Label
        {
            Text = "AZUR BOT",
            Font = new Font("Segoe UI", 18, FontStyle.Bold),
            AutoSize = true,
            Left = 25, Top = 18
        };

        startButton.Left = 25; startButton.Top = 65;
        stopButton.Left = 190; stopButton.Top = 65;
        status.Left = 25; status.Top = 135;
        hpLabel.Left = 25; hpLabel.Top = 160;

        startButton.Click += (_, _) => StartBot();
        stopButton.Click += (_, _) => StopBot();
        Controls.AddRange([title, startButton, stopButton, status, hpLabel]);

        FormClosing += (_, _) => StopBot();
    }

    private void StartBot()
    {
        if (busy) return;
        busy = true;
        cts = new CancellationTokenSource();
        startButton.Enabled = false;
        stopButton.Enabled = true;
        SetStatus("Démarré. Place le jeu sur Chrome.");
        _ = Task.Run(() => LoopAsync(cts.Token));
    }

    private void StopBot()
    {
        cts?.Cancel();
        busy = false;
        startButton.Enabled = true;
        stopButton.Enabled = false;
        SetStatus("Arrêté");
    }

    private void SetStatus(string text)
    {
        if (IsDisposed) return;
        BeginInvoke(() => status.Text = text);
    }

    private void SetHp(double? hp)
    {
        if (IsDisposed) return;
        BeginInvoke(() => hpLabel.Text = hp.HasValue ? $"HP : {hp.Value:0} %" : "HP : --");
    }

    private async Task LoopAsync(CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            try
            {
                using var bmp = CaptureVirtualScreen();
                var hp = DetectGreenHp(bmp);
                SetHp(hp);

                var text = await ReadFrenchTextAsync(bmp);

                // Safety rule: only click a known target when its text is actually recognized.
                if (Contains(text, "RENTRER AU VILLAGE") && hp.HasValue && hp.Value < 55)
                {
                    SetStatus("HP < 55 % : retour au village");
                    await ClickTextAsync(bmp, text, "RENTRER AU VILLAGE", token);
                }
                else if (Contains(text, "CONTINUER") && hp.HasValue && hp.Value >= 55)
                {
                    SetStatus("Victoire : continuer");
                    await ClickTextAsync(bmp, text, "CONTINUER", token);
                }
                else if (Contains(text, "REPARTIR"))
                {
                    SetStatus("Rapport : repartir");
                    await ClickTextAsync(bmp, text, "REPARTIR", token);
                }
                else if (Contains(text, "PARTIR"))
                {
                    SetStatus("Préparation : partir");
                    await ClickTextAsync(bmp, text, "PARTIR", token);
                }
                else
                {
                    SetStatus("Analyse...");
                }

                await Task.Delay(900, token);
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex)
            {
                SetStatus("Erreur : " + ex.Message);
                await Task.Delay(1500, token);
            }
        }
    }

    private static bool Contains(string text, string wanted)
        => text.Replace("’", "'").IndexOf(wanted, StringComparison.OrdinalIgnoreCase) >= 0;

    private static Bitmap CaptureVirtualScreen()
    {
        var bounds = SystemInformation.VirtualScreen;
        var bmp = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format32bppArgb);
        using var g = Graphics.FromImage(bmp);
        g.CopyFromScreen(bounds.Left, bounds.Top, 0, 0, bounds.Size);
        return bmp;
    }

    private static double? DetectGreenHp(Bitmap bmp)
    {
        // Based on the supplied mobile layout, scaled proportionally for PC.
        int x0 = (int)(bmp.Width * 0.06);
        int x1 = (int)(bmp.Width * 0.48);
        int y0 = (int)(bmp.Height * 0.12);
        int y1 = (int)(bmp.Height * 0.30);

        int bestRun = 0, bestY = -1;
        for (int y = y0; y < y1; y += 2)
        {
            int run = 0, localBest = 0;
            for (int x = x0; x < x1; x += 2)
            {
                var c = bmp.GetPixel(x, y);
                bool green = c.G > 70 && c.G > c.R * 1.30 && c.G > c.B * 1.10;
                if (green) { run++; localBest = Math.Max(localBest, run); }
                else run = 0;
            }
            if (localBest > bestRun) { bestRun = localBest; bestY = y; }
        }

        if (bestRun < 8 || bestY < 0) return null;

        // Estimate filled fraction from the longest green run.
        int total = Math.Max(1, (x1 - x0) / 2);
        double fraction = Math.Clamp((double)bestRun / total, 0, 1);
        return fraction * 100.0;
    }

    private static async Task<string> ReadFrenchTextAsync(Bitmap bmp)
    {
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;

        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);

        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();

        var result = await engine.RecognizeAsync(sb);
        return result.Text ?? "";
    }

    private static async Task ClickTextAsync(Bitmap bmp, string fullText, string wanted, CancellationToken token)
    {
        // Re-run OCR with word boxes so we can click the recognized button itself.
        using var ms = new System.IO.MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        ms.Position = 0;

        using var ras = new InMemoryRandomAccessStream();
        await ras.WriteAsync(ms.ToArray().AsBuffer());
        ras.Seek(0);

        var decoder = await BitmapDecoder.CreateAsync(ras);
        var sb = await decoder.GetSoftwareBitmapAsync();
        var engine = OcrEngine.TryCreateFromLanguage(new Language("fr-FR"))
                     ?? OcrEngine.TryCreateFromUserProfileLanguages();
        var result = await engine.RecognizeAsync(sb);

        var normalizedWanted = wanted.Replace("!", "").Trim();
        foreach (var line in result.Lines)
        {
            var lineText = line.Text.Replace("!", "").Trim();
            if (lineText.IndexOf(normalizedWanted, StringComparison.OrdinalIgnoreCase) < 0)
                continue;

            var rect = line.Words.Select(w => w.BoundingRect).ToArray();
            if (rect.Length == 0) continue;

            double left = rect.Min(r => r.X);
            double top = rect.Min(r => r.Y);
            double right = rect.Max(r => r.X + r.Width);
            double bottom = rect.Max(r => r.Y + r.Height);

            int x = (int)((left + right) / 2);
            int y = (int)((top + bottom) / 2);

            // Avoid accidental clicks near screen edges.
            if (x < 5 || y < 5 || x >= bmp.Width - 5 || y >= bmp.Height - 5) return;

            NativeClick.Click(x + SystemInformation.VirtualScreen.Left,
                              y + SystemInformation.VirtualScreen.Top);
            await Task.Delay(1400, token);
            return;
        }
    }
}
